<?php
Configure::write('CakePluginTest.test_plugin.routes', 'loaded plugin routes');